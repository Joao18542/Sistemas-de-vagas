package com.example.vagas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VagasApplicationTests {

	@Test
	void contextLoads() {
		// Teste vazio, pode ser removido ou substituído por testes reais
	
	}

}
