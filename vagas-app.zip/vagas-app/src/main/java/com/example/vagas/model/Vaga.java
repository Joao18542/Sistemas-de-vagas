package com.example.vagas.model;

import java.util.List;

public class Vaga {
    private String idvaga;
    private String descricaoCargo;
    private List<String> requisitosObrigatorios;
    private List<String> requisitosDesejaveis;
    private String remuneracaoMensal;
    private List<String> beneficios;
    private String localTrabalho;

    // Getters e Setters
    public String getIdvaga() {
        return idvaga;
    }

    public void setIdvaga(String idvaga) {
        this.idvaga = idvaga;
    }

    public String getDescricaoCargo() {
        return descricaoCargo;
    }

    public void setDescricaoCargo(String descricaoCargo) {
        this.descricaoCargo = descricaoCargo;
    }

    public List<String> getRequisitosObrigatorios() {
        return requisitosObrigatorios;
    }

    public void setRequisitosObrigatorios(List<String> requisitosObrigatorios) {
        this.requisitosObrigatorios = requisitosObrigatorios;
    }

    public List<String> getRequisitosDesejaveis() {
        return requisitosDesejaveis;
    }

    public void setRequisitosDesejaveis(List<String> requisitosDesejaveis) {
        this.requisitosDesejaveis = requisitosDesejaveis;
    }

    public String getRemuneracaoMensal() {
        return remuneracaoMensal;
    }

    public void setRemuneracaoMensal(String remuneracaoMensal) {
        this.remuneracaoMensal = remuneracaoMensal;
    }

    public List<String> getBeneficios() {
        return beneficios;
    }

    public void setBeneficios(List<String> beneficios) {
        this.beneficios = beneficios;
    }

    public String getLocalTrabalho() {
        return localTrabalho;
    }

    public void setLocalTrabalho(String localTrabalho) {
        this.localTrabalho = localTrabalho;
    }
}

