package com.example.vagas.controller;

import com.example.vagas.model.Vaga;
import com.example.vagas.service.VagaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;
import java.util.Optional;

@Controller
public class VagaController {

    @Autowired
    private VagaService vagaService;

    @GetMapping("/vagas")
    public String listarVagas(Model model) {
        List<Vaga> vagas = vagaService.findAll();
        model.addAttribute("vagas", vagas);
        return "vagas/lista";
    }

    @GetMapping("/vagas/{id}")
    public String detalharVaga(@PathVariable String id, Model model) {
        Optional<Vaga> vaga = vagaService.findById(id);
        if (vaga.isPresent()) {
            model.addAttribute("vaga", vaga.get());
            return "vagas/detalhe";
        } else {
            return "redirect:/vagas";
        }
    }
}

