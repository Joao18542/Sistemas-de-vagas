package com.example.vagas.service;

import com.example.vagas.model.Vaga;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Service;
import org.springframework.util.ResourceUtils;

import java.io.File;
import java.io.IOException;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

@Service
public class VagaService {

    private List<Vaga> vagas;

    public VagaService() {
        try {
            File file = ResourceUtils.getFile("classpath:vagas-db.json");
            ObjectMapper objectMapper = new ObjectMapper();
            vagas = objectMapper.readValue(file, new TypeReference<List<Vaga>>() {});
        } catch (IOException e) {
            e.printStackTrace();
            vagas = Collections.emptyList();
        }
    }

    public List<Vaga> findAll() {
        return vagas;
    }

    public Optional<Vaga> findById(String id) {
        return vagas.stream()
                .filter(vaga -> vaga.getIdvaga().equals(id))
                .findFirst();
    }
}

